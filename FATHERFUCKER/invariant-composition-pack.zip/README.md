# Invariant Composition — Installation Overlay

Copy `MOTHERFUCKER/` into the repository root, preserving paths.

Then run:

```bash
cd MOTHERFUCKER
node --test tests/invariant-composition.test.mjs
node --test tests/invariant-composition.integration.test.mjs
node tools/render-invariant-demo.mjs
```

The pack targets the formal framework state introduced in commit
`0824d965f27e036ede2ba05aee3aab6b69238118`.

No existing files are replaced except that the ZIP adds
`src/load-capability-scene-pack.mjs`, a capability-aware loader required because
the current core `renderer.loadPack()` validates before activating the
`capabilityPacks` declared inside a scene pack.

Included:

- 12 assets;
- 12 semantic mechanisms;
- new invariant/dynamical mathematics;
- procedural geometry;
- 12-scene demonstration;
- pure math tests;
- activation/validation integration tests;
- render command;
- design review and API documentation.
